#ifndef MotorController_h
#define MotorController_h

#include "Arduino.h"
#include <Servo.h>

class MotorController
{

  friend class PID;

  public:
    MotorController(int motorPins[4], int motorSpeedOffsets[4] = {});                       //constructor

    void writeMotor(int motorNumber, int newSpeed);                                         //sets the speed of one motor
    void writeMotors(int speeds[]);                                                         //sets the speed of all motors
    void adjustMotors(float adjustments[]);                                                   //adjust the speed of all motors
    void adjustMotor(int motorNumber, int adjustment);                                      //adjust the speed of one motor
    void motorTest();                                                                       //just runs the motors through several speeds to make sure they are working
    void changeOffsets(int newOffsets[4]);

  private:                                                                       //just runs the motors through several speeds to make sure they are working
    int motorPins[4];                                                                       //holds the signal pin for each motors ESC
    Servo motors[4];                                                                        //each ESC take signals like that of a servo, so we can use the Servo class to handle all the specifics of generating signals
    int motorSpeedOffsets[4];                                                               //holds the offsets we use to make the motors run at the same speed
    int currentMotorSpeeds[4] = {0, 0, 0, 0};                                               //keeps track of the speed of every motor
  
};

#endif
