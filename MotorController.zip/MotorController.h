#ifndef MotorController_h
#define MotorController_h

#include "Arduino.h"
#include <Servo.h>

class MotorController
{

  friend class PID;

  public:
    MotorController(int motorPins[4], int motorSpeedOffsets[4] = {});
    
  private:
    void writeMotor(int motorNumber, int newSpeed);
    void writeMotors(int speeds[]);
    void adjustMotors(int adjustments[]);
    void adjustMotor(int motorNumber, int adjustment);
    void motorTest();

    int motorPins[4];
    Servo motors[4];
    int motorSpeedOffsets[4];
    int currentMotorSpeeds[4] = {0, 0, 0, 0};
  
};

#endif
