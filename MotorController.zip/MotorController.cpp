#include "MotorController.h"

MotorController::MotorController(int p_motorPins[4], int p_motorSpeedOffsets[4] = {})
{

  memcpy(motorPins, p_motorPins, sizeof(p_motorPins));
  memcpy(motorSpeedOffsets, p_motorSpeedOffsets, sizeof(p_motorSpeedOffsets));

  for(int i = 0; i < 4; i++) {motors[i].attach(motorPins[i]);}
  
}

void MotorController::writeMotor(int motorNumber, int newSpeed)
{
  currentMotorSpeeds[motorNumber - 1] = newSpeed - motorSpeedOffsets[motorNumber - 1];
  motors[motorNumber - 1].writeMicroseconds(currentMotorSpeeds[motorNumber - 1]);
}

void MotorController::writeMotors(int speeds[])
{

  for(int i = 0; i < 4; i++) 
  {
    motors[i].writeMicroseconds(speeds[i] - motorSpeedOffsets[i]); 
    currentMotorSpeeds[i] = speeds[i] - motorSpeedOffsets[i];
  }
  
}

void MotorController::adjustMotors(int adjustments[])
{

   for(int i = 0; i < 4; i++) {currentMotorSpeeds[i] += adjustments[i];}
   writeMotors(currentMotorSpeeds);

}

void MotorController::adjustMotor(int motorNumber, int adjustment) {writeMotor(motorNumber, currentMotorSpeeds[motorNumber - 1] + adjustment);}

void MotorController::motorTest()
{

  for(int i = 0; i < 1000; i += 10) {int testSpeeds[4] = {1000 + i, 1000 + i, 1000 + i, 1000 + i}; writeMotors(testSpeeds); delay(100);}
  for(int i = 1000; i > 0; i -= 10) {int testSpeeds[4] = {1000 + i, 1000 + i, 1000 + i, 1000 + i}; writeMotors(testSpeeds); delay(100);}
  
}
