#include "oAvoider.h"

ObstacleAvoider::ObstacleAvoider(int newPins[4][2], int maxDistance, int minDistance)
{
  memcpy(sensorPins, newPins, sizeof(sensorPins));
  this->maxDistance = mxDistance;
  this->minDistance = minDistance;
  for(int i = 0; i < 4; i++) {pinMode(sensorPins[i][0], OUTPUT); pinMode(sensorPins[i][1], INPUT);}
}

int ObstacleAvoider::getMinDistance(){return minDistance;}
void ObstacleAvoider::setMinDistance(int minDistance) {this->minDistance = minDistance;}

int ObstacleAvoider::getMaxDistance(){return maxDistance;}
void ObstacleAvoider::setMaxDistance(int maxDistance) {this->maxDistance = maxDistance;}

void ObstacleAvoider::setSensorPins(int sensorPins[4][2]) {memcpy(this->sensorPins, sensorPins, sizeof(sensorPins));}

int ObstacleAvoider::getReading(int axis)
{
  digitalWrite(sensorPins[axis][0], LOW);
  delayMicroseconds(2);
  digitalWrite(sensorPins[axis][0], HIGH);
  delayMicroseconds(10);
  digitalWrite(sensorPins[axis][0], LOW);
  return pulseIn(sensorPins[axis][1], HIGH);
}

int *ObstacleAvoider::getReadings()
{
  int readings[4];
  for(int i = 0; i < 4; i++) {readings[i] = getReading(i);}
  return readings;
}

float ObstacleAvoider::getDistance(int reading)
{return reading*0.034/2;}

float *ObstacleAvoider::getDistances(int readings[])
{
  float distances[4];
  for(int i = 0; i < 4; i++) {distances[i] = getDistance(readings[i]);}
  return distances;
}

float ObstacleAvoider::obstacleAvoidAxis(int axis, float proportional, float integral, float derivative)
{
 int reading = getReading(axis);
 float distance = getDistance(reading);
 if(distance == 0 || distance > maxDistance) {return 0;}
 float tempForce = proportional + integral + derivative;
 float mapped = map(distance, maxDistance, minDistance, 0, tempForce);
 if(mapped == NAN) {return 0;}
 else if(mapped > tempForce) {return tempForce;}
 else if(mapped < 0) {return 0;}
 return mapped;
}

float *ObstacleAvoider::obstacleAvoid(float proportional[4], float integral[4], float derivative[4])
{
  float adjusts[4];
  for(int i = 0; i < 4; i++) {adjusts[i] = obstacleAvoidAxis(i, proportional[i], integral[4], derivative[i]);}
  return adjusts;
}

