#ifndef IMU_h
#define IMU_h

#include "Arduino.h"
#include <Wire.h>
#include "I2Cdev.h"
#include <BMP085.h>
#include "HMC5883L.h"

class IMU
{

  friend class PID;

  public:
    IMU(long int seaLPress, float accPO = 0, float accRO = 0);                                            //constructor

    int *readIMUdata();                                                      //Will run through and call all of the below functions to update all the IMU data
    void readMPUdataRaw();                                                   //Handles getting all the raw data from the MPU6050 and prepares it for calculations
    void readMPUdata();                                                      //Converts raw MPU6050 data in readable/useable forms that actually have meaning
    void readBMPdata();                                                      //Reads in barometer(altitude/airpressure) data
    void readMCLdata();                                                      //Reads in directional data(bearing in relation to North)

    int gyroX, gyroY, gyroZ;                                                 //holds the rate of change the quadcopter's angles detected by the MPU6050
    long int accX, accY, accZ, accMag;                                       //hold the acceleration values of their respective axsis and the magnitude
    float anglePitch, angleRoll;                                             //first the gyro calculated angles, then the IMU pitch and roll values
    float angleRollAcc, anglePitchAcc;                                       //calculated rotaion angles based off accelerometer
    
    int temperature;                                                         //self explanatory bruh... really?.. you really want me to explain it? *sigh*.. it holds the calculated temperature reading from the MPU6050
    float heading; 

    int pressure;                                                            //holds the air pressure readings
    long int altitude;                                                       //holds the current altitude
      
  private:
    void setupMPU6050Registers();
    void calibrateGyro();
    long gyroXoffset, gyroYoffset, gyroZoffset;                              //used for calibration of the initial gyro reading offsets
    boolean setGyroAngles = 0;                                               //used to trigger initial angle readings, only is used on startup
    
    float accPitchOffset = 0, accRollOffset = 0;                             //offsets for the accelerometer values, laying it flat is the best way to calculate these
    float gyroContribution;                                            //used for the complimentary filter, how much weight the gyro's measurments are given vs the accelerometer
    int lastClock;
    
    BMP085 bmp;                                                              //The barometer object
    long int seaLevelPress;                                                  //holds the local air pressure at sea level(used for altitude), must be entered
    
    HMC5883L mag;                                                         //The magentometer object
    int16_t mx, my, mz;                                                      //holds magentic field values on each axis
                                                              //will store your angle in relation to the north pole, 0 = North
  
  
};

#endif

