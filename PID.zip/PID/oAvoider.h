#ifndef oAvoider_h
#define oAvoider_h

#include "Arduino.h"

class ObstacleAvoider
{

  friend class PIDcontroller;

  public:
    ObstacleAvoider(int newPins[4][2], int maxDistance, int minDistance);
    float obstacleAvoidAxis(int axis, float proportional, float integral, float derivative);
    float *obstacleAvoid(float proportional[4], float integral[4], float derivative[4]);
    void setMinDistance(int newMin);
    int getMinDistance();
    void setMaxDistance(int newMax);
    int getMaxDistance();
    void setSensorPins(int newPins[4][2]);
    
  private:
    int getReading(int axis);
    int *getReadings();
    float getDistance(int reading);
    float *getDistances(int readings[]);
    int sensorPins[4][2];
    int minDistance;
    int maxDistance;
    
};

#endif
