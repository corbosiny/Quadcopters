#ifndef PID_h
#define PID_h

#include "Arduino.h"
#include "MotorController.h"
#include "IMU.h"

class PIDcontroller
{

  public:
  PIDcontroller(int motorPins[4], int constants[3], int seaLevelPress, int accelPO = 0, int accelRO = 0);
  void adjustAxis(int axisNum); 
  void changeTargets(int newTargets[4]);
  void changeTarget(int index, int newTarget);
  int *calibrateMotors();
  
  private:
  int pins[4]; 
  float targets[4];
  float vibrationThresh;
  float lastErrors[4] = {0,0,0,0};
  boolean targetsChanged[4] = {false, false, false, false};
  float integrals[4] = {0,0,0,0};
  long long int dt;
  float proConstant;
  float intConstant;
  float derConstant;
  IMU imu = NULL;
  MotorController motors = NULL;
  
};


#endif
