#ifndef PID_h
#define PID_h

#include "Arduino.h"
#include "MotorController.h"
#include "IMU.h"

class PIDcontroller
{

  public:
  PIDcontroller(int motorPins[4], int constants[3], int seaLevelPress, int accelPO = 0, int accelRO = 0);
  void adjustAxis(int axisNum); 
  void changeTargets(int newTargets[4]);
  void changeTarget(int index, int newTarget);
  int *calibrateMotors();
  
  private:
  int pins[4]; 
  int targets[4];
  float vibrationThresh;
  int lastErrors[4] = {0,0,0,0};
  int integrals[4] = {0,0,0,0};
  long long int dt;
  int proConstant;
  int intConstant;
  int derConstant;
  IMU imu = NULL;
  MotorController motors = NULL;
  
};


#endif
